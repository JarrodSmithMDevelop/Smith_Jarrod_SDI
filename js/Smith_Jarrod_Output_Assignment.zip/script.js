/**
 * Created by JarrodSmith on 10/1/15.
 */

    //Jarrod smith
    //SDI Section 1
    //Output Assignment

// Variables

var numKids = 3;                             	//Number of kids    int variable
var kids = ["Shelby", "Jodeah", "Elijah"];  		//My kids names     Array of strings
var ageOfKids = [12, 7, 5];                 		//My kids ages      Array of integers
var favGame = "Minecraft";                  		//My daughters favorite game    String variable
var favColor = true;                        		//Sons favorite color is blue   Boolean variable
var favSport = "Baseball";                  		//Sons favorite sport           String variable

// Output

// Printing information about Shelby
console.log ("I have " + numKids + " kids and they are awesome! But I would like to tell you some about them. \n" + kids[0] +
    " was my first born she is now " + ageOfKids[0] + ". She likes to play video games and her favorite game is " + favGame + ".");

// Printing information about Jodeah
console.log ("My second child is " + kids[1] + ", he just turned " + ageOfKids[1] + " back in June. He really thinks he is big now. \n" +
    "It is " + favColor + " that blue is Jodeah\'s favorite color." );

// Printing information about Elijah
console.log ("My youngest son is " + kids[2] + ", he just turned " + ageOfKids[2] + ". He is also the only child in the house that's favorite \n" +
    "sport is " + favSport + ".");

